<!DOCTYPE html>
<html>
<head>
    <title>New Contact Form Submission</title>
</head>
<body>
    <h2>New Project Inquiry</h2>

    <p><strong>Full Name:</strong> <?php echo e($data['full_name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Company Name:</strong> <?php echo e($data['company_name']); ?></p>
    <p><strong>Phone Number:</strong> <?php echo e($data['phone_number']); ?></p>
    <p><strong>Your Message:</strong></p>
    <p><?php echo e($data['your_message']); ?></p>
</body>
</html>
<?php /**PATH /home/u217315144/domains/development.astrapent.com/public_html/api/resources/views/emails/contact_us_form.blade.php ENDPATH**/ ?>