<!DOCTYPE html>
<html>
<head>
    <title>New Contact Form Submission</title>
</head>
<body>
    <h2>New Project Inquiry</h2>

    <p><strong>Full Name:</strong> <?php echo e($data['full_name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($data['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($data['phone']); ?></p>
    <p><strong>Project Type:</strong> <?php echo e($data['project_type']); ?></p>
    <p><strong>Project Details:</strong></p>
    <p><?php echo e($data['project_details']); ?></p>
</body>
</html>
<?php /**PATH /home/u217315144/domains/development.astrapent.com/public_html/api/resources/views/emails/contact_form.blade.php ENDPATH**/ ?>